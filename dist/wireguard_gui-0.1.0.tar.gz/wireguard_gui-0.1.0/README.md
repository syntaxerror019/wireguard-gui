# Simple WireGuard GUI

A modern, easy-to-use desktop GUI for WireGuard, built with Python and CustomTkinter.

## Installation

```bash
pip install .
```

## Usage

```bash
wireguard-gui
```
